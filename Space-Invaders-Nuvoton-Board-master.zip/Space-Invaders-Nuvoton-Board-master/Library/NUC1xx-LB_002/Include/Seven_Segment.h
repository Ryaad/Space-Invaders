#ifndef __Seven_Segment_H__
#define __Seven_Segment_H__
     
extern void show_seven_segment(unsigned char no, unsigned char number);
extern void close_seven_segment(void);
#endif
